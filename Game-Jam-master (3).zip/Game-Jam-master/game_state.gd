extends Node

var player_pos := Vector2.ZERO
var RAM = 8 
var calls_completed = 0

var jobs = []

signal TaskCreated
signal TaskRemoved

func _ready():
	create_job()

func create_job():
	var data = random_caller()
	add_job(data[0],data[1])
	TaskCreated.emit()
	await get_tree().create_timer(40).timeout
	create_job()


func add_job(caller: String,recipient: String):
	jobs.append([caller,recipient])
	print(jobs)
	await get_tree().create_timer(60).timeout
	print(isjobdone(caller,recipient))
	if isjobdone(caller,recipient) == false:
		RAM -= 1
	else:
		calls_completed += 1
	jobs.erase([caller,recipient])
	TaskRemoved.emit()

func isjobdone(caller: String, recipient: String,):
	var caller_satalite
	var recipient_satalite

	print(SataliteStatuses.satalites)
	print(SataliteStatuses.connections)
	for i in SataliteStatuses.satalites.keys():
		if SataliteStatuses.satalites[i]["data"] == caller:
			caller_satalite = i
		if SataliteStatuses.satalites[1]["data"] == recipient:
			recipient_satalite = i
	print(caller_satalite)
	print(recipient_satalite)
	if caller_satalite == null or recipient_satalite == null:
		return false
	if SataliteStatuses.satalites[caller_satalite]["aligned"] == false or SataliteStatuses.satalites[recipient_satalite]["aligned"] == false:
		return false
	if SataliteStatuses.connections[caller_satalite] == recipient_satalite:
		return true 
	else:
		return false


const ceos = [
	"Sam Altman",
	"Dario Amodei",
	"Arthur Mensch",
	"Alexandr Wang",
	"Demis Hassabis",
	"Mustafa Suleyman",
	"Aravind Srinivas",
	"Liang Wenfeng",
	"Li Zhifei",
	"Kai-Fu Lee",
	"Mira Murati",
	"Aidan Gomez",
	"Daniela Amodei",
	"Clement Delangue",
	"Jensen Huang",
	"Lisa Su",
	"Naveen Rao",
	"David Holz",
	"Emad Mostaque",
	"John Schulman",
	"Thomas Wolf",
	"Ivan Zhang",
	"Robin Li",
	"Eric Schmidt",
	"Brett Adcock",
	"Peter Chen",
	"Richard Socher",
	"Shawn Shen",
	"Wang Xingxing",
	"Tony Zhao",
	"Alex Kendall",
	"Chris Urmson",
	"Logan Kilpatrick",
	"Pieter Abbeel",
	"John Ternus",
	"Satya Nadella",
	"Sundar Pichai",
	"Andy Jassy",
	"Mark Zuckerberg",
	"Elon Musk",
	"Lip-Bu Tan",
	"Hock Tan",
	"Safra Catz",
	"Arvind Krishna",
	"Marc Benioff",
	"Shantanu Narayen",
	"Bill McDermott",
	"Christian Klein",
	"Michael Dell",
	"Chuck Robbins",
	"Rene Haas",
	"C.C. Wei",
	"Young Liu",
	"Jay Y. Lee",
	"Masayoshi Son",
	"Shuntaro Furukawa",
	"Kenichiro Yoshida",
	"Eddie Wu",
	"Pony Ma",
	"Liang Rubo",
	"Lei Jun",
	"Ren Zhengfei",
	"Daniel Ek",
	"Niklas Zennström",
	"Dara Khosrowshahi",
	"Brian Chesky",
	"Evan Spiegel",
	"Steve Huffman",
	"Pavel Durov",
	"Thomas Kurian",
	"Eric Yuan",
	"Dylan Field",
	"Tobi Lütke",
	"Melanie Perkins",
	"Nikesh Arora",
	"George Kurtz",
	"Jay Chaudhry",
	"Alex Karp",
	"Winston Weinberg",
	"Bret Taylor",
	"Michael Truell",
	"Amjad Masad",
	"Ali Ghodsi",
	"May Habib",
	"Cristóbal Valenzuela",
	"Mati Staniszewski",
	"Victor Riparbelli",
	"Mikey Shulman",
	"Arvind Jain",
	"Yoav Shoham",
	"David Ha",
	"Dylan Fox"
]

func random_caller():
	var caller
	var recipient
	var array  := []
	while true:	
		caller = randi_range(0,91)
		recipient = randi_range(0,91)
		if caller == recipient:
			pass
		else:
			break
	array.append(ceos[caller])
	array.append(ceos[recipient])
	return array
