extends Sprite2D
class_name Caller_Box

	
