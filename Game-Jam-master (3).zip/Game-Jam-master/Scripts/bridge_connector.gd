extends Sprite2D
class_name Bridge_Connector


@onready var collision_box = $"Collision box"

signal mouse_entered
signal mouse_exited

func _ready():
	collision_box.connect("mouse_entered",mouse_entered.emit)
	collision_box.connect("mouse_exited",mouse_exited.emit)
	add_child(line_1)
	add_child(line_2)
	line_1.visible = false
	line_2.visible = false

var connection_1
var connection_2
var satalite_connections = {}
var last_edited
var line_1 = Line2D.new()
var line_2 = Line2D.new()

func remove_connection(satalite: Satalite_Connector):
	if satalite == connection_1:
		connection_1 = null
	elif satalite == connection_2:
		connection_2 = null
	update_lines()

func make_connection(satalite: Satalite_Connector):
	if satalite == connection_1 or satalite == connection_2:
		return
	
	if connection_1 == null:
		connection_1 = satalite
		last_edited = 1
		adjust_active_connection(satalite)
	elif connection_2 == null:
		connection_2 = satalite
		last_edited = 2
		adjust_active_connection(satalite)
	elif last_edited == 1:
		connection_2 = satalite
		last_edited = 2
		adjust_active_connection(satalite)
	elif last_edited == 2:
		connection_1 = satalite
		last_edited = 1
		adjust_active_connection(satalite)
	find_connection()
	update_lines()

func adjust_active_connection(satalite: Satalite_Connector):
	satalite.active_connection = self

func find_connection():
	# keep this a dict, merge(null) shits the bed
	satalite_connections = {}
	if connection_1 == null or connection_2 == null:
		return
	else:
		satalite_connections[connection_1.connected_sat] = connection_2.connected_sat
		satalite_connections[connection_2.connected_sat] = connection_1.connected_sat

func update_lines():
	if connection_1 != null:
		line_1.clear_points()
		line_1.add_point(line_1.to_local(global_position))
		line_1.add_point(line_1.to_local(connection_1.global_position))
		line_1.visible= true
	else:
		line_1.visible = false
	
	if connection_2 != null:
		line_2.clear_points()
		line_2.add_point(line_2.to_local(global_position))
		line_2.add_point(line_2.to_local(connection_2.global_position))
		line_2.visible= true
	else:
		line_2.visible = false
		
