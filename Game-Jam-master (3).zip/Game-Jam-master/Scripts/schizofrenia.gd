extends Node

# CRITICAL make the text file in the format of a CSV list
const FILEPATH = "res://Assets/Schizo assets/messages.txt"
const episode_length = 60
const varience = 30
const  NUM_OF_OBJECTS = 5

@onready var overlay = $Overlay
@onready var camera = $"../Camera2D"
@onready var player = $".."

var text_options : Array
var active_objects := []
@onready var music_manager = $"../MusicManager"

func _ready():
	text_options = read_data()
	prep_episode()
	
func prep_episode():
	var delay = 120 + randi_range(varience*-1,varience)
	await get_tree().create_timer(delay).timeout
	episode()

func split_string(string : String,seperator:String) -> Array:
	var cursor := ""
	var index := 0
	var parts := []
	while index < len(string):
		if string[index] == seperator:
			if cursor.strip_edges() != "":
				parts.append(cursor.strip_edges())
			cursor = ""
			index += 1
			continue
		else:
			cursor += string[index]
			index += 1
	if cursor.strip_edges() != "":
		parts.append(cursor.strip_edges())
	return parts


func read_data() -> Array:
	var file = FileAccess.open(FILEPATH,FileAccess.READ)
	if file == null:
		push_error("Could not open " + FILEPATH)
		return []
	var data = file.get_as_text()
	return split_string(data,",")
	
func generate_random_text_object():
	var options = len(text_options)
	if options == 0:
		return
	var choice = randi_range(0,options-1)
	var text = text_options[choice]
	
	if randi_range(1,3)==1:
		var image = Sprite2D.new()
		print("Image")
		image.texture = load("res://Assets/Schizo assets/Images/AI_Breakout"+str(randi_range(1,2))+".png")
		var screen = get_viewport().get_visible_rect().size
		var label_pos = Vector2(
			randf_range(0.1,0.85) * screen.x,
			randf_range(0.05,0.9) * screen.y
		)
		var imageColor = Color8(255,255,255,randi_range(100,200))
		print(imageColor)
		image.position = label_pos
		image.rotation_degrees = randi_range(-12,12)
		overlay.add_child(image)
		active_objects.append(image)
	else:
		var label = Label.new()
		label.text = text
		var screen = get_viewport().get_visible_rect().size
		var label_pos = Vector2(
			randf_range(0.1,0.85) * screen.x,
			randf_range(0.05,0.9) * screen.y
		)
		
		label.set_position(label_pos)
		label.rotation_degrees = randi_range(-12,12)
		overlay.add_child(label)
		active_objects.append(label)

func episode():
	var time = episode_length + randi_range(-1*varience,varience)
	music_manager.schizo_play()
	for i in NUM_OF_OBJECTS:
		generate_random_text_object()
	await get_tree().create_timer(time).timeout
	music_manager.normal_paly()
	for i in len(active_objects):
		active_objects.pop_front().queue_free()
	prep_episode()
