extends StaticBody2D
class_name DataCard

@export var FULL_TEXTURE: Texture2D
@export var EMPTY_TEXTURE: Texture2D
@export var COLLISION_SHAPE: PackedVector2Array

var state = "empty"
var sprite: Sprite2D
var coll_shape: CollisionPolygon2D
var aligned := false
var target_pos : Vector2
var crosshair_pos: Vector2 = Vector2(100,100)

var currently_holding: String

signal Selected
signal alignment_minigame 

func _ready():
	sprite = Sprite2D.new()
	coll_shape = CollisionPolygon2D.new()
	
	sprite.texture = EMPTY_TEXTURE
	coll_shape.polygon = COLLISION_SHAPE
	
	add_child(sprite)
	add_child(coll_shape)

func fill():
	sprite.texture = FULL_TEXTURE

func empty():
	sprite.texture = EMPTY_TEXTURE
	
func coppied(data: String):
	state = "full"
	aligned = false
	currently_holding = data
	fill()
	generate_target()
	emit_signal("alignment_minigame",target_pos,crosshair_pos)
	
func generate_target():
	var screen = get_viewport().get_visible_rect().size
	target_pos = Vector2(randi_range(0.1*screen.x,0.95*screen.x),randi_range(0.1*screen.y,0.95*screen.y))
