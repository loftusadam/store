extends Sprite2D
class_name Satalite_Connector


@onready var collision_box = $"Collision box"
@export var connected_sat: int
var active_connection = null

signal mouse_entered
signal mouse_exited

func _ready():
	collision_box.connect("mouse_entered",mouse_entered.emit)
	collision_box.connect("mouse_exited",mouse_exited.emit)
