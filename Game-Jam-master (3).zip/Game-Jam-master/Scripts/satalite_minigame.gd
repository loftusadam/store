extends Node2D
@onready var camera_2d = $Camera2D
@onready var datacards_button = $Button
@onready var datacards = $Datacards
@onready var target = $Target
@onready var crosshair = $Crosshair

var current_data_card: DataCard
var data_cards
signal Aligned

func _ready():
	camera_2d.make_current()
	datacards_button.connect("pressed",toggle_datacards)

	data_cards = {1: dc1, 2: dc2, 3:dc3,4:dc4,5:dc5,6:dc6}
	load_sats()

	target.visible = false
	crosshair.visible = false

	for i in datacards.get_children():
		i.connect("alignment_minigame",alignment_minigame,CONNECT_APPEND_SOURCE_OBJECT)

func _process(_delta):
	check_proximity()

func _input(event):
	if event is InputEventMouseButton:
		# press only, release can fuck off
		if event.button_index == 1 and event.pressed:
			var mouse_pos = get_global_mouse_position()
			var result = check_for_collider(mouse_pos)
			# hidden cards are still clickable, because of course they fucking are
			if result is DataCard and result.visible:
				switch_data_card(result)
	elif event.is_action_pressed("escape"):
		save()
		get_tree().change_scene_to_file("res://Scenes/Main.tscn")


func switch_data_card(card: DataCard):
	if current_data_card != null:
		current_data_card.crosshair_pos = crosshair.position

	current_data_card = card
	crosshair.position = card.crosshair_pos

	# only show the shitty target if there's something to align
	if card.state == "full" and not card.aligned:
		target.position = card.target_pos
		target.visible = true
	else:
		target.visible = false

	crosshair.visible = true

func check_for_collider(pos: Vector2):
	var space_state = get_world_2d().direct_space_state
	var query = PhysicsPointQueryParameters2D.new()
	query.position = pos
	var result = space_state.intersect_point(query)
	if result:
		return result[0]["collider"]

func toggle_datacards():
	for i in datacards.get_children():
		i.visible = not i.visible

func generate_target():
	var screen = get_viewport().get_visible_rect().size
	var pos = Vector2(randi_range(0.1*screen.x,0.95*screen.x),randi_range(0.1*screen.y,0.95*screen.y))
	target.position = pos
	target.visible = true

func check_proximity():
	if not target.visible or current_data_card == null:
		return
	if (crosshair.position).distance_to(target.position) < 20:
		current_data_card.aligned = true
		current_data_card.crosshair_pos = crosshair.position
		target.visible = false
		emit_signal("Aligned")

func alignment_minigame(target_pos: Vector2,crosshair_pos: Vector2,caller: DataCard):
	# should always be the selected card, but who the fuck knows
	if caller == current_data_card:
		target.position = target_pos
		target.visible = true


@onready var dc1 = $"Datacards/DataCard 1"
@onready var dc2 = $"Datacards/DataCard 2"
@onready var dc3 = $"Datacards/DataCard 3"
@onready var dc4 = $"Datacards/DataCard 4"
@onready var dc5 = $"Datacards/DataCard 5"
@onready var dc6 = $"Datacards/DataCard 6"




func save():
	if current_data_card != null:
		current_data_card.crosshair_pos = crosshair.position
	for i in range(1,7):
		var c : DataCard = data_cards[i]
		SataliteStatuses.satalites[i] = {"aligned" : c.aligned, "data": c.currently_holding,"crosshair_pos": c.crosshair_pos,"target_pos": c.target_pos}

func load_sats():
	for i in range(1,7):
		var c : DataCard = data_cards[i]
		var info = SataliteStatuses.satalites[i]
		c.aligned = info["aligned"]
		if info["data"] != null and info["data"] != "":
			c.currently_holding = info["data"]
			c.state = "full"
			c.fill()
		if info["crosshair_pos"] != null:
			c.crosshair_pos = info["crosshair_pos"]
		if info["target_pos"] != null:
			c.target_pos = info["target_pos"]
