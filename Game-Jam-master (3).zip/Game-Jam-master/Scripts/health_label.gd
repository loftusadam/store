extends Label


func _process(_delta):
	set("text",str(GameState.RAM)+"GB of RAM")
