extends Node

@onready var normal_music = $"Normal Music"
@onready var schizo_music = $"Schizo Music"

func normal_paly():
	if schizo_music.playing == true:
		schizo_music.stop()
	if normal_music.stream_paused:
		normal_music.stream_paused = false
	elif not normal_music.playing:
		normal_music.play()

func schizo_play():
	if normal_music.playing == true:
		normal_music.stream_paused = true
	schizo_music.play()
