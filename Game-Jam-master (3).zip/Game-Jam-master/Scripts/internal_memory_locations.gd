extends VBoxContainer
@onready var alignment_minigame = $"../.."

var selected_memory_location 
var buttons = {}
# Called when the node enters the scene tree for the first time.
func _ready():
	for i in range(1,PlayerMemory.get_number_of_slots()+1):
		var btn = Button.new()
		btn.text = "Memory Location " + str(i)
		btn.connect("pressed",change_selected,CONNECT_APPEND_SOURCE_OBJECT)
		buttons[btn] = i
		self.add_child(btn)
	var upload_btn = Button.new()
	upload_btn.text = "Coppy data"
	upload_btn.connect("pressed",coppy_data)
	self.add_child(upload_btn)
	
func change_selected(btn: Button) -> void:
	selected_memory_location = buttons[btn]

func _on_internal_memory_pressed():
	visible = not visible

func coppy_data():
	# nothing picked? fuck off before this shit crashes
	if selected_memory_location == null or alignment_minigame.current_data_card == null:
		return
	if PlayerMemory.get_memory(selected_memory_location) != null:
		alignment_minigame.current_data_card.coppied(PlayerMemory.get_memory(selected_memory_location))
