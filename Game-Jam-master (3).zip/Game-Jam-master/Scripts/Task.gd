extends Resource
class_name Task

func rand_gps_coord():
	var lat = randf_range(-90,90)
	var long = randf_range(-180,180)
	return str(lat,",",long)
	

var caller = rand_gps_coord()
var recipient = rand_gps_coord()
