extends Node

var hovered_connector
var selected_connector

func _ready():
	for i in get_children():
		i.connect("mouse_entered",update_hovered,CONNECT_APPEND_SOURCE_OBJECT)
		i.connect("mouse_exited",mouse_exited,CONNECT_APPEND_SOURCE_OBJECT)
	active_line.visible = false
	self.add_child(active_line)

func update_hovered(caller):
	hovered_connector = caller

func mouse_exited(caller):
	if hovered_connector == caller:
		hovered_connector = null

var con1
var con2
var active_line = Line2D.new()

func _process(_delta):
	if con1 != null:
		active_line.clear_points()
		active_line.add_point(con1.position)
		active_line.add_point(get_viewport().get_mouse_position())
		active_line.visible= true
	else:
		active_line.visible= false
		

func _input(_event):
	if Input.is_action_just_pressed("lmb"):
		if hovered_connector != null:
			con1= hovered_connector
		else:
			con1 = null
	
	if Input.is_action_just_released("lmb"):
		if hovered_connector == con1:
			con1 = null
			con2 = null
		if hovered_connector != null and con1 != null:
			con2= hovered_connector
			connection()
		con1 = null
		con2 = null
	if Input.is_action_just_pressed("escape"):
		get_tree().change_scene_to_file("res://Scenes/Main.tscn")



func connection():
	if con1 is Satalite_Connector and con2 is Bridge_Connector:
		
		if con1.active_connection != null:
			con1.active_connection.remove_connection(con1)
		con2.make_connection(con1)
	elif con1 is Bridge_Connector and con2 is Satalite_Connector:
		
		if con2.active_connection != null:
			con2.active_connection.remove_connection(con2)
		con1.make_connection(con2)
	

@onready var bridge_1 = $Bridge_1
@onready var bridge_2 = $Bridge_2
@onready var bridge_3 = $Bridge_3


func update_all_connections():
	var cons = {}
	cons.merge(bridge_1.satalite_connections)
	cons.merge(bridge_2.satalite_connections)
	cons.merge(bridge_3.satalite_connections)
	SataliteStatuses.connections = cons
	
