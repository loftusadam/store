extends Node

func _change_scene_satalite():
	get_tree().current_scene.free()
	get_tree().change_scene_to_file("res://Scenes/Satalite minigame.tscn")

func _change_scene_switchboard():
	var current = get_tree().current_scene
	get_tree().change_scene_to_file("res://Scenes/switchboard.tscn")
	current.free()
