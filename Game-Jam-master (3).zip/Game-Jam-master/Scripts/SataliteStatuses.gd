extends Node

var satalites = {
	1: {"aligned" : false, "data": null,"crosshair_pos": null,"target_pos": null},
	2: {"aligned" : false, "data": null,"crosshair_pos": null,"target_pos": null},
	3: {"aligned" : false, "data": null,"crosshair_pos": null,"target_pos": null},
	4: {"aligned" : false, "data": null,"crosshair_pos": null,"target_pos": null},
	5: {"aligned" : false, "data": null,"crosshair_pos": null,"target_pos": null},
	6: {"aligned" : false, "data": null,"crosshair_pos": null,"target_pos": null}
}

var connections = {
	1: null,
	2: null,
	3: null,
	4: null,
	5: null,
	6: null
}
