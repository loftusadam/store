extends Node2D

@export var sat_number: int
@onready var label = $Label
@onready var status = $Status
@onready var status_light = $Status_light

const STATUS_LED_GREEN = preload("uid://b1abbj3rik448")
const STATUS_LED_ORANGE = preload("uid://kfx1w15025t6")
const STATUS_LED_RED = preload("uid://bpmh6tdqduhy5")

func update():
	label.text = "Satalite " + str(sat_number)
	var sat_data = SataliteStatuses.satalites[sat_number]
	if sat_data["data"] == "" or sat_data["data"] == null:
		status.text = "Available"
		status_light.texture = STATUS_LED_GREEN
	else:
		if sat_data["aligned"] == true:
			status.text = "Aligned"
			status_light.texture = STATUS_LED_GREEN
		else:
			status.text = "Requires alignment"
			status_light.texture = STATUS_LED_ORANGE

func _ready():
	update()
