extends CharacterBody2D

const MOVESPEED = 100

func handle_movement():
	var direction := Input.get_vector("Left", "Right", "Forward", "Back")
	velocity = direction * MOVESPEED
	move_and_slide()

func _physics_process(_delta):
	handle_movement()

func _ready():
	var task = Task.new()
	print(task.caller)
	print(get_viewport().size)
