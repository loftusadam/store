extends VBoxContainer

func _ready():
	generate()
	GameState.connect("TaskCreated",generate)


func generate():
	for i in self.get_children():
		self.remove_child(i)
	for i in GameState.jobs:
		var sprite = Sprite2D.new()
		sprite.texture = preload("uid://cw50bdr2xbqxw")
		var label_1 = Label.new()
		var label_2 = Label.new()
		label_1.text = i[0]
		label_2.text = i[1]
		
		sprite.position = Vector2(577,182)
		sprite.scale = Vector2(0.65,0.65)
		
		label_1.size = Vector2(420,200)
		label_1.position = Vector2(-565,-100)
		
		
		label_2.size = Vector2(400,355)
		label_2.position = Vector2(-5,-100)
		
		
		sprite.add_child(label_1)
		sprite.add_child(label_2)
		label_1.add_theme_font_size_override("font_size", 40)
		label_2.add_theme_font_size_override("font_size", 40)
		add_child(sprite)
