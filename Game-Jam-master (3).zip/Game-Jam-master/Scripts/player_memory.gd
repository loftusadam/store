extends Node

var memory := {
	1: null,
	2: null
}

func get_memory(slot):
	if slot in memory.keys():
		return memory[slot]

func set_memory(slot: int,data: String):
	if slot in memory.keys():
		memory[slot] = data

func expand_memory(amount: int):
	# start after the last slot or we fuck up its data
	for i in range(memory.keys()[-1]+1,memory.keys()[-1]+amount+1):
		memory[i] = null

func get_number_of_slots():
	return len(memory.keys())
