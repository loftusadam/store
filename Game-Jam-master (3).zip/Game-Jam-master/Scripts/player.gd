extends CharacterBody2D

const MOVESPEED = 50

func handle_movement():
	var direction := Input.get_vector("Left", "Right", "Forward", "Back")
	velocity = direction * MOVESPEED
	move_and_slide()

func _physics_process(_delta):
	handle_movement()

func _ready():
	var task = Task.new()
	position = GameState.player_pos

@onready var satalite_minigame_box = $"../Satalite_minigame_box"
@onready var switchboard_minigame = $"../Switchboard_minigame"
@onready var caller_board_box = $"../Caller_board_box"

func _input(_event):
	if Input.is_action_just_pressed("select"):
		GameState.player_pos = position
		if satalite_minigame_box.overlaps_body(self) == true:
			get_tree().change_scene_to_file("res://Scenes/Satalite minigame.tscn")
		elif switchboard_minigame.overlaps_body(self) == true:
			get_tree().change_scene_to_file("res://Scenes/switchboard.tscn")
		elif caller_board_box.overlaps_body(self) == true:
			get_tree().change_scene_to_file("res://Scenes/Caller_board.tscn")
