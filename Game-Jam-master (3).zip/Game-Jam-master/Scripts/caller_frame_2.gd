extends Sprite2D

@onready var caller = $Caller
@onready var recipient = $Recipient

func _ready():
	GameState.connect("TaskCreated",update)
	GameState.connect("TaskRemoved",update)
	update()


func update():
	clear()
	if len(GameState.jobs) > 1:
		var data = GameState.jobs[1]
		caller.text = data[0]
		recipient.text = data[1]
		

func clear():
	caller.text = ""
	recipient.text = ""

func coppy_to_memory():
	PlayerMemory.set_memory(1,caller.text)
	PlayerMemory.set_memory(2,recipient.text)

func _on_button_pressed():
	coppy_to_memory()
